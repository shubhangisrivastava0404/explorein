"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Slider } from "@/components/ui/slider"
import { Badge } from "@/components/ui/badge"
import { AlertCircle, Play } from "lucide-react"

interface DatasetInfo {
  filename: string
  rows: number
  columns: number
  columnNames: string[]
  columnTypes: Record<string, string>
  missingValues: Record<string, number>
}

interface AnalysisConfig {
  analysisType: "eda" | "classification" | "regression" | "clustering" | "timeseries"
  targetVariable?: string
  features?: string[]
  testSize: number
  randomState: number
  modelTypes: string[]
}

interface AnalysisConfigComponentProps {
  datasetInfo: DatasetInfo
  config: AnalysisConfig
  onConfigChange: (config: AnalysisConfig) => void
  onStartAnalysis: () => void
}

export function AnalysisConfigComponent({
  datasetInfo,
  config,
  onConfigChange,
  onStartAnalysis,
}: AnalysisConfigComponentProps) {
  const updateConfig = (updates: Partial<AnalysisConfig>) => {
    onConfigChange({ ...config, ...updates })
  }

  const numericColumns = Object.entries(datasetInfo.columnTypes)
    .filter(([_, type]) => type === "numeric")
    .map(([name]) => name)

  const categoricalColumns = Object.entries(datasetInfo.columnTypes)
    .filter(([_, type]) => type === "categorical")
    .map(([name]) => name)

  const modelOptions = {
    classification: ["Random Forest", "Logistic Regression", "SVM", "XGBoost", "Neural Network"],
    regression: ["Linear Regression", "Random Forest", "XGBoost", "Ridge Regression", "Lasso Regression"],
    clustering: ["K-Means", "DBSCAN", "Hierarchical Clustering", "Gaussian Mixture"],
    timeseries: ["ARIMA", "Prophet", "LSTM", "Exponential Smoothing"],
    eda: [],
  }

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Configure Analysis</h2>
        <p className="text-gray-600">Set up your analysis parameters and select the models to train</p>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Dataset Overview */}
        <Card>
          <CardHeader>
            <CardTitle>Dataset Overview</CardTitle>
            <CardDescription>Summary of your uploaded dataset</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-sm font-medium text-gray-500">Filename</Label>
                <p className="font-medium">{datasetInfo.filename}</p>
              </div>
              <div>
                <Label className="text-sm font-medium text-gray-500">Dimensions</Label>
                <p className="font-medium">
                  {datasetInfo.rows} × {datasetInfo.columns}
                </p>
              </div>
            </div>

            <div>
              <Label className="text-sm font-medium text-gray-500 mb-2 block">Column Types</Label>
              <div className="flex flex-wrap gap-2">
                {numericColumns.map((col) => (
                  <Badge key={col} variant="secondary" className="bg-blue-100 text-blue-800">
                    {col} (numeric)
                  </Badge>
                ))}
                {categoricalColumns.map((col) => (
                  <Badge key={col} variant="secondary" className="bg-green-100 text-green-800">
                    {col} (categorical)
                  </Badge>
                ))}
              </div>
            </div>

            {Object.values(datasetInfo.missingValues).some((count) => count > 0) && (
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                <div className="flex items-center mb-2">
                  <AlertCircle className="w-4 h-4 text-yellow-600 mr-2" />
                  <span className="text-sm font-medium text-yellow-800">Missing Values Detected</span>
                </div>
                <div className="text-xs text-yellow-700">
                  {Object.entries(datasetInfo.missingValues)
                    .filter(([_, count]) => count > 0)
                    .map(([col, count]) => `${col}: ${count}`)
                    .join(", ")}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Analysis Configuration */}
        <Card>
          <CardHeader>
            <CardTitle>Analysis Settings</CardTitle>
            <CardDescription>Configure your analysis parameters</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="analysis-type">Analysis Type</Label>
              <Select value={config.analysisType} onValueChange={(value: any) => updateConfig({ analysisType: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Select analysis type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="eda">Exploratory Data Analysis</SelectItem>
                  <SelectItem value="classification">Classification</SelectItem>
                  <SelectItem value="regression">Regression</SelectItem>
                  <SelectItem value="clustering">Clustering</SelectItem>
                  <SelectItem value="timeseries">Time Series</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {(config.analysisType === "classification" || config.analysisType === "regression") && (
              <div>
                <Label htmlFor="target-variable">Target Variable</Label>
                <Select
                  value={config.targetVariable}
                  onValueChange={(value) => updateConfig({ targetVariable: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select target variable" />
                  </SelectTrigger>
                  <SelectContent>
                    {(config.analysisType === "regression" ? numericColumns : datasetInfo.columnNames).map((col) => (
                      <SelectItem key={col} value={col}>
                        {col}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {config.analysisType !== "eda" && (
              <div>
                <Label>Test Set Size: {config.testSize * 100}%</Label>
                <Slider
                  value={[config.testSize * 100]}
                  onValueChange={([value]) => updateConfig({ testSize: value / 100 })}
                  max={40}
                  min={10}
                  step={5}
                  className="mt-2"
                />
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Model Selection */}
      {config.analysisType !== "eda" && (
        <Card>
          <CardHeader>
            <CardTitle>Model Selection</CardTitle>
            <CardDescription>Choose which models to train and compare</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {modelOptions[config.analysisType].map((model) => (
                <div key={model} className="flex items-center space-x-2">
                  <Checkbox
                    id={model}
                    checked={config.modelTypes.includes(model)}
                    onCheckedChange={(checked) => {
                      if (checked) {
                        updateConfig({
                          modelTypes: [...config.modelTypes, model],
                        })
                      } else {
                        updateConfig({
                          modelTypes: config.modelTypes.filter((m) => m !== model),
                        })
                      }
                    }}
                  />
                  <Label htmlFor={model} className="text-sm font-medium">
                    {model}
                  </Label>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Start Analysis Button */}
      <div className="text-center">
        <Button
          onClick={onStartAnalysis}
          size="lg"
          className="px-8"
          disabled={
            (config.analysisType !== "eda" && config.modelTypes.length === 0) ||
            ((config.analysisType === "classification" || config.analysisType === "regression") &&
              !config.targetVariable)
          }
        >
          <Play className="w-4 h-4 mr-2" />
          Start AI Analysis
        </Button>
        <p className="text-sm text-gray-500 mt-2">
          This will take 2-5 minutes depending on dataset size and selected models
        </p>
      </div>
    </div>
  )
}
