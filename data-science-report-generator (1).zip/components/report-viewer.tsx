"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Download, FileText, BarChart3, TrendingUp, Award, Lightbulb, MessageCircle } from "lucide-react"
import { AIChat } from "@/components/ai-chat"
import { EnhancedCharts } from "@/components/enhanced-charts"

interface ReportData {
  summary: {
    datasetName: string
    analysisType: string
    totalRows: number
    totalColumns: number
    missingValuesHandled: number
    modelsTrained: number
  }
  insights: string[]
  modelResults: {
    bestModel: string
    accuracy: number
    precision: number
    recall: number
    f1Score: number
  }
  visualizations: Array<{
    type: string
    title: string
  }>
}

interface ReportViewerProps {
  reportData: ReportData
  onExportReport: () => void
}

export function ReportViewer({ reportData, onExportReport }: ReportViewerProps) {
  const [isChatVisible, setIsChatVisible] = useState(false)

  // Mock data for visualizations
  const correlationData = [
    { feature: "Income", correlation: 0.72 },
    { feature: "Experience", correlation: 0.68 },
    { feature: "Education", correlation: 0.45 },
    { feature: "Location", correlation: 0.23 },
    { feature: "Age", correlation: 0.12 },
  ]

  const featureImportanceData = [
    { feature: "Income", importance: 0.35 },
    { feature: "Experience", importance: 0.28 },
    { feature: "Education", importance: 0.18 },
    { feature: "Department", importance: 0.12 },
    { feature: "Location", importance: 0.07 },
  ]

  const performanceData = [
    { metric: "Accuracy", value: reportData.modelResults.accuracy * 100 },
    { metric: "Precision", value: reportData.modelResults.precision * 100 },
    { metric: "Recall", value: reportData.modelResults.recall * 100 },
    { metric: "F1-Score", value: reportData.modelResults.f1Score * 100 },
  ]

  const distributionData = [
    { category: "High Performance", value: 35, color: "#10B981" },
    { category: "Medium Performance", value: 45, color: "#F59E0B" },
    { category: "Low Performance", value: 20, color: "#EF4444" },
  ]

  const modelComparisonData = [
    { model: "Random Forest", accuracy: 87.3 },
    { model: "Linear Regression", accuracy: 82.1 },
    { model: "SVM", accuracy: 79.8 },
    { model: "XGBoost", accuracy: 85.6 },
  ]

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Analysis Report</h2>
          <p className="text-gray-600">Comprehensive data science analysis results</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={() => setIsChatVisible(!isChatVisible)} variant="outline" className="flex items-center">
            <MessageCircle className="w-4 h-4 mr-2" />
            AI Assistant
          </Button>
          <Button onClick={onExportReport} className="flex items-center">
            <Download className="w-4 h-4 mr-2" />
            Export PDF Report
          </Button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <FileText className="w-5 h-5 text-blue-500" />
              <div>
                <p className="text-sm font-medium text-gray-500">Dataset</p>
                <p className="text-lg font-bold">{reportData.summary.totalRows?.toLocaleString()} rows</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <BarChart3 className="w-5 h-5 text-green-500" />
              <div>
                <p className="text-sm font-medium text-gray-500">Features</p>
                <p className="text-lg font-bold">{reportData.summary.totalColumns}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Award className="w-5 h-5 text-purple-500" />
              <div>
                <p className="text-sm font-medium text-gray-500">Best Model</p>
                <p className="text-lg font-bold">{reportData.modelResults.bestModel}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <TrendingUp className="w-5 h-5 text-orange-500" />
              <div>
                <p className="text-sm font-medium text-gray-500">Accuracy</p>
                <p className="text-lg font-bold">{(reportData.modelResults.accuracy * 100).toFixed(1)}%</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="insights" className="space-y-4">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="insights">AI Insights</TabsTrigger>
          <TabsTrigger value="performance">Model Performance</TabsTrigger>
          <TabsTrigger value="visualizations">Visualizations</TabsTrigger>
          <TabsTrigger value="advanced">Advanced Charts</TabsTrigger>
          <TabsTrigger value="summary">Executive Summary</TabsTrigger>
        </TabsList>

        <TabsContent value="insights" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Lightbulb className="w-5 h-5 mr-2 text-yellow-500" />
                AI-Generated Insights
              </CardTitle>
              <CardDescription>Key findings and recommendations from your data analysis</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {reportData.insights.map((insight, index) => (
                  <div key={index} className="flex items-start space-x-3 p-4 bg-gray-50 rounded-lg">
                    <div className="flex-shrink-0 w-6 h-6 bg-blue-500 text-white rounded-full flex items-center justify-center text-sm font-bold">
                      {index + 1}
                    </div>
                    <p className="text-gray-700 leading-relaxed">{insight}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="performance" className="space-y-4">
          <div className="grid lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Model Performance Metrics</CardTitle>
                <CardDescription>Evaluation metrics for the best performing model</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {performanceData.map((metric) => (
                    <div key={metric.metric} className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm font-medium">{metric.metric}</span>
                        <span className="text-sm font-bold">{metric.value.toFixed(1)}%</span>
                      </div>
                      <Progress value={metric.value} className="h-2" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Feature Importance</CardTitle>
                <CardDescription>Most influential features for predictions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {featureImportanceData.map((item, index) => (
                    <div key={item.feature} className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm font-medium">{item.feature}</span>
                        <span className="text-sm font-bold">{(item.importance * 100).toFixed(1)}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-blue-500 h-2 rounded-full transition-all duration-500"
                          style={{ width: `${item.importance * 100}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="visualizations" className="space-y-4">
          <div className="grid lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Feature Correlations</CardTitle>
                <CardDescription>Correlation with target variable</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {correlationData.map((item, index) => (
                    <div key={item.feature} className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm font-medium">{item.feature}</span>
                        <span className="text-sm font-bold">{item.correlation.toFixed(2)}</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-green-500 h-2 rounded-full transition-all duration-500"
                          style={{ width: `${item.correlation * 100}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Target Distribution</CardTitle>
                <CardDescription>Distribution of performance categories</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {distributionData.map((item, index) => (
                    <div key={item.category} className="flex items-center space-x-3">
                      <div className="w-4 h-4 rounded-full" style={{ backgroundColor: item.color }} />
                      <div className="flex-1">
                        <div className="flex justify-between mb-1">
                          <span className="text-sm font-medium">{item.category}</span>
                          <span className="text-sm font-bold">{item.value}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="h-2 rounded-full transition-all duration-500"
                            style={{
                              width: `${item.value}%`,
                              backgroundColor: item.color,
                            }}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Model Comparison</CardTitle>
                <CardDescription>Performance comparison across different models</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {modelComparisonData.map((item, index) => (
                    <div key={item.model} className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm font-medium">{item.model}</span>
                        <span className="text-sm font-bold">{item.accuracy.toFixed(1)}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-3">
                        <div
                          className="bg-purple-500 h-3 rounded-full transition-all duration-700"
                          style={{ width: `${(item.accuracy / 100) * 100}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Data Quality Overview</CardTitle>
                <CardDescription>Missing values and data completeness</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Data Completeness</span>
                      <span className="text-sm font-bold">94.2%</span>
                    </div>
                    <Progress value={94.2} className="h-3" />
                  </div>

                  <div className="grid grid-cols-2 gap-4 pt-4">
                    <div className="text-center p-3 bg-blue-50 rounded-lg">
                      <p className="text-2xl font-bold text-blue-600">{reportData.summary.missingValuesHandled}</p>
                      <p className="text-xs text-blue-600">Missing Values Handled</p>
                    </div>
                    <div className="text-center p-3 bg-orange-50 rounded-lg">
                      <p className="text-2xl font-bold text-orange-600">23</p>
                      <p className="text-xs text-orange-600">Outliers Detected</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-3 bg-green-50 rounded-lg">
                      <p className="text-2xl font-bold text-green-600">8</p>
                      <p className="text-xs text-green-600">Features Engineered</p>
                    </div>
                    <div className="text-center p-3 bg-purple-50 rounded-lg">
                      <p className="text-2xl font-bold text-purple-600">99.1%</p>
                      <p className="text-xs text-purple-600">Data Accuracy</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="advanced" className="space-y-4">
          <EnhancedCharts reportData={reportData} />
        </TabsContent>

        <TabsContent value="summary" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Executive Summary</CardTitle>
              <CardDescription>High-level overview of analysis results</CardDescription>
            </CardHeader>
            <CardContent className="prose max-w-none">
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Dataset Overview</h4>
                  <p className="text-gray-700">
                    Analysis was performed on <strong>{reportData.summary.datasetName}</strong> containing{" "}
                    <strong>{reportData.summary.totalRows?.toLocaleString()} records</strong> and{" "}
                    <strong>{reportData.summary.totalColumns} features</strong>. Data preprocessing handled{" "}
                    <strong>{reportData.summary.missingValuesHandled} missing values</strong> across multiple columns.
                  </p>
                </div>

                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Model Performance</h4>
                  <p className="text-gray-700">
                    After training and evaluating {reportData.summary.modelsTrained} different models, the{" "}
                    <strong>{reportData.modelResults.bestModel}</strong> achieved the best performance with an accuracy
                    of <strong>{(reportData.modelResults.accuracy * 100).toFixed(1)}%</strong>. The model demonstrates
                    strong predictive capability with balanced precision (
                    {(reportData.modelResults.precision * 100).toFixed(1)}%) and recall (
                    {(reportData.modelResults.recall * 100).toFixed(1)}%).
                  </p>
                </div>

                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Key Recommendations</h4>
                  <ul className="list-disc list-inside text-gray-700 space-y-1">
                    <li>Focus on income and experience as primary predictive factors</li>
                    <li>Consider department-specific strategies for performance improvement</li>
                    <li>Implement the Random Forest model for production predictions</li>
                    <li>Monitor model performance and retrain quarterly with new data</li>
                  </ul>
                </div>

                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Technical Details</h4>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="font-medium">Analysis Type:</span> {reportData.summary.analysisType}
                      </div>
                      <div>
                        <span className="font-medium">Models Trained:</span> {reportData.summary.modelsTrained}
                      </div>
                      <div>
                        <span className="font-medium">Best Model:</span> {reportData.modelResults.bestModel}
                      </div>
                      <div>
                        <span className="font-medium">F1-Score:</span>{" "}
                        {(reportData.modelResults.f1Score * 100).toFixed(1)}%
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* AI Chat Component */}
      <AIChat reportData={reportData} isVisible={isChatVisible} onToggle={() => setIsChatVisible(!isChatVisible)} />
    </div>
  )
}
