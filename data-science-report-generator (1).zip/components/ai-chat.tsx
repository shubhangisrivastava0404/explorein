"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { MessageCircle, Send, Bot, User, Lightbulb, BarChart3 } from "lucide-react"

interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: Date
}

interface AIChatProps {
  reportData: any
  isVisible: boolean
  onToggle: () => void
}

export function AIChat({ reportData, isVisible, onToggle }: AIChatProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      role: "assistant",
      content: `Hello! I'm your AI Data Science Assistant. I've analyzed your dataset "${reportData?.summary?.datasetName}" and I'm ready to answer any questions about your analysis results. You can ask me about:

• Model performance and recommendations
• Feature importance and correlations  
• Data quality insights
• Business implications of the findings
• Next steps for implementation

What would you like to know?`,
      timestamp: new Date(),
    },
  ])
  const [inputValue, setInputValue] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const scrollAreaRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    if (scrollAreaRef.current) {
      const scrollContainer = scrollAreaRef.current.querySelector("[data-radix-scroll-area-viewport]")
      if (scrollContainer) {
        scrollContainer.scrollTop = scrollContainer.scrollHeight
      }
    }
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const generateAIResponse = async (userMessage: string): Promise<string> => {
    // Simulate AI response based on the user's question and report data
    const lowerMessage = userMessage.toLowerCase()

    if (lowerMessage.includes("model") || lowerMessage.includes("performance")) {
      return `Based on your analysis, the ${reportData.modelResults.bestModel} achieved the best performance with ${(reportData.modelResults.accuracy * 100).toFixed(1)}% accuracy. This model outperformed others because:

• **High Precision**: ${(reportData.modelResults.precision * 100).toFixed(1)}% - meaning most positive predictions are correct
• **Good Recall**: ${(reportData.modelResults.recall * 100).toFixed(1)}% - capturing most actual positive cases
• **Balanced F1-Score**: ${(reportData.modelResults.f1Score * 100).toFixed(1)}% - good overall performance

The Random Forest model works well for your dataset because it handles mixed data types effectively and provides feature importance insights.`
    }

    if (lowerMessage.includes("feature") || lowerMessage.includes("important")) {
      return `The most important features in your dataset are:

🔹 **Income** (35% importance) - The strongest predictor of performance
🔹 **Experience** (28% importance) - Years of experience significantly impact outcomes  
🔹 **Education** (18% importance) - Educational background plays a moderate role
🔹 **Department** (12% importance) - Some departments show higher performance
🔹 **Location** (7% importance) - Geographic factors have minimal impact

**Recommendation**: Focus your strategies on income optimization and experience development programs for maximum impact.`
    }

    if (lowerMessage.includes("improve") || lowerMessage.includes("recommendation")) {
      return `Based on your analysis, here are my top recommendations to improve performance:

🎯 **Immediate Actions:**
• Focus on the Engineering department - it shows 15% higher performance
• Prioritize income and experience factors in hiring/promotion decisions
• Age has minimal impact, so avoid age-based assumptions

📊 **Data Strategy:**
• Collect more data on high-performing individuals
• Monitor model performance quarterly and retrain as needed
• Consider A/B testing different strategies based on these insights

🚀 **Implementation:**
• Deploy the Random Forest model for production predictions
• Set up automated monitoring for model drift
• Create department-specific improvement programs`
    }

    if (lowerMessage.includes("data") || lowerMessage.includes("quality")) {
      return `Your data quality is excellent! Here's the breakdown:

✅ **Data Completeness**: 94.2% - Very good coverage
✅ **Missing Values**: Only ${reportData.summary.missingValuesHandled} values needed handling
✅ **Outliers**: 23 detected and properly managed
✅ **Data Accuracy**: 99.1% - High reliability

**Quality Insights:**
• Your dataset has ${reportData.summary.totalRows.toLocaleString()} rows with ${reportData.summary.totalColumns} features
• The data preprocessing was successful with minimal data loss
• No significant data quality issues that would impact model reliability

This high data quality contributes to the strong model performance you're seeing.`
    }

    if (lowerMessage.includes("business") || lowerMessage.includes("impact")) {
      return `The business impact of your analysis is significant:

💰 **Financial Impact:**
• 87.3% prediction accuracy can reduce hiring/promotion errors by ~85%
• Focus on income and experience factors could improve ROI on talent investments
• Department-specific strategies could boost overall performance by 15%

📈 **Strategic Insights:**
• Engineering department is your top performer - consider expanding this team
• Experience is highly predictive - invest in retention and development programs
• Location has minimal impact - remote work policies won't hurt performance

🎯 **Action Items:**
• Implement the Random Forest model for decision support
• Create targeted development programs based on feature importance
• Monitor performance metrics quarterly to track improvement`
    }

    // Default response
    return `That's a great question! Based on your analysis of ${reportData.summary.totalRows.toLocaleString()} records, I can see that your ${reportData.modelResults.bestModel} model achieved ${(reportData.modelResults.accuracy * 100).toFixed(1)}% accuracy. 

Could you be more specific about what aspect you'd like to explore? I can help with:
• Model performance details
• Feature importance explanations  
• Business recommendations
• Data quality insights
• Implementation strategies

Feel free to ask about any specific aspect of your analysis!`
  }

  const handleSendMessage = async () => {
    if (!inputValue.trim() || isLoading) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: inputValue.trim(),
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInputValue("")
    setIsLoading(true)

    try {
      // Simulate API delay
      await new Promise((resolve) => setTimeout(resolve, 1500))

      const aiResponse = await generateAIResponse(userMessage.content)

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: aiResponse,
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, assistantMessage])
    } catch (error) {
      console.error("Error generating AI response:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  const suggestedQuestions = [
    "Why is Random Forest the best model?",
    "What features should I focus on?",
    "How can I improve performance?",
    "What's the business impact?",
  ]

  if (!isVisible) {
    return (
      <Button onClick={onToggle} className="fixed bottom-6 right-6 h-14 w-14 rounded-full shadow-lg z-50" size="icon">
        <MessageCircle className="h-6 w-6" />
      </Button>
    )
  }

  return (
    <Card className="fixed bottom-6 right-6 w-96 h-[600px] shadow-2xl z-50 flex flex-col">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center text-lg">
            <Bot className="w-5 h-5 mr-2 text-blue-500" />
            AI Data Assistant
          </CardTitle>
          <Button variant="ghost" size="sm" onClick={onToggle}>
            ×
          </Button>
        </div>
        <div className="flex gap-1">
          <Badge variant="secondary" className="text-xs">
            <BarChart3 className="w-3 h-3 mr-1" />
            Analysis Ready
          </Badge>
          <Badge variant="secondary" className="text-xs">
            <Lightbulb className="w-3 h-3 mr-1" />
            AI Powered
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col p-0">
        <ScrollArea className="flex-1 px-4" ref={scrollAreaRef}>
          <div className="space-y-4 pb-4">
            {messages.map((message) => (
              <div key={message.id} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}>
                <div
                  className={`max-w-[80%] rounded-lg p-3 ${
                    message.role === "user" ? "bg-blue-500 text-white" : "bg-gray-100 text-gray-900 border"
                  }`}
                >
                  <div className="flex items-start space-x-2">
                    {message.role === "assistant" && <Bot className="w-4 h-4 mt-0.5 text-blue-500" />}
                    {message.role === "user" && <User className="w-4 h-4 mt-0.5" />}
                    <div className="flex-1">
                      <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                      <p className={`text-xs mt-1 ${message.role === "user" ? "text-blue-100" : "text-gray-500"}`}>
                        {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            ))}

            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-gray-100 rounded-lg p-3 border">
                  <div className="flex items-center space-x-2">
                    <Bot className="w-4 h-4 text-blue-500" />
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" />
                      <div
                        className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                        style={{ animationDelay: "0.1s" }}
                      />
                      <div
                        className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                        style={{ animationDelay: "0.2s" }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </ScrollArea>

        {/* Suggested Questions */}
        {messages.length === 1 && (
          <div className="px-4 py-2 border-t">
            <p className="text-xs text-gray-500 mb-2">Try asking:</p>
            <div className="flex flex-wrap gap-1">
              {suggestedQuestions.map((question, index) => (
                <Button
                  key={index}
                  variant="outline"
                  size="sm"
                  className="text-xs h-7"
                  onClick={() => setInputValue(question)}
                >
                  {question}
                </Button>
              ))}
            </div>
          </div>
        )}

        {/* Input Area */}
        <div className="p-4 border-t">
          <div className="flex space-x-2">
            <Input
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Ask about your analysis..."
              disabled={isLoading}
              className="flex-1"
            />
            <Button onClick={handleSendMessage} disabled={isLoading || !inputValue.trim()} size="icon">
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
