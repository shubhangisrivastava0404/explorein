"use client"

import type React from "react"
import { useState, useCallback, useRef } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Upload, FileText, Loader2, CheckCircle, AlertCircle } from "lucide-react"

interface DataUploadProps {
  onFileUpload: (file: File) => void
  isProcessing: boolean
}

export function DataUpload({ onFileUpload, isProcessing }: DataUploadProps) {
  const [dragActive, setDragActive] = useState(false)
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [error, setError] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      setDragActive(false)
    }
  }, [])

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)
    setError(null)

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0]
      if (isValidFile(file)) {
        setSelectedFile(file)
      } else {
        setError("Please upload a valid CSV or Excel file (.csv, .xlsx, .xls)")
      }
    }
  }, [])

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    setError(null)
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0]
      if (isValidFile(file)) {
        setSelectedFile(file)
      } else {
        setError("Please upload a valid CSV or Excel file (.csv, .xlsx, .xls)")
      }
    }
  }

  const isValidFile = (file: File) => {
    const validTypes = [
      "text/csv",
      "application/vnd.ms-excel",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ]
    const validExtensions = [".csv", ".xlsx", ".xls"]
    const hasValidType = validTypes.includes(file.type)
    const hasValidExtension = validExtensions.some((ext) => file.name.toLowerCase().endsWith(ext))
    const isValidSize = file.size <= 100 * 1024 * 1024 // 100MB limit

    return (hasValidType || hasValidExtension) && isValidSize
  }

  const handleUpload = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    console.log("Upload button clicked!")
    if (selectedFile) {
      console.log("Starting upload for file:", selectedFile.name)
      onFileUpload(selectedFile)
    }
  }

  const handleReset = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setSelectedFile(null)
    setError(null)
  }

  const handleBrowseClick = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    fileInputRef.current?.click()
  }

  const handleDropZoneClick = (e: React.MouseEvent) => {
    // Only trigger file browser if no file is selected and not clicking on buttons
    if (!selectedFile && !isProcessing) {
      const target = e.target as HTMLElement
      if (!target.closest("button")) {
        fileInputRef.current?.click()
      }
    }
  }

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Upload Your Dataset</h2>
        <p className="text-gray-600">Upload a CSV or Excel file to begin automated data analysis</p>
      </div>

      <Card className="max-w-2xl mx-auto">
        <CardContent className="p-6">
          {/* Hidden file input */}
          <input
            ref={fileInputRef}
            type="file"
            accept=".csv,.xlsx,.xls,text/csv,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            onChange={handleFileSelect}
            className="hidden"
            disabled={isProcessing}
          />

          <div
            className={`border-2 border-dashed rounded-lg p-8 text-center transition-all duration-200 ${
              dragActive
                ? "border-blue-500 bg-blue-50 scale-105"
                : selectedFile
                  ? "border-green-500 bg-green-50"
                  : "border-gray-300 hover:border-gray-400 hover:bg-gray-50"
            } ${isProcessing ? "opacity-50" : ""}`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
            onClick={handleDropZoneClick}
            style={{ cursor: selectedFile || isProcessing ? "default" : "pointer" }}
          >
            {selectedFile ? (
              <div className="space-y-4">
                <CheckCircle className="w-12 h-12 text-green-500 mx-auto" />
                <div>
                  <p className="font-medium text-gray-900">{selectedFile.name}</p>
                  <p className="text-sm text-gray-500">{(selectedFile.size / 1024 / 1024).toFixed(2)} MB</p>
                </div>
                <div className="flex gap-2 justify-center">
                  <Button onClick={handleUpload} disabled={isProcessing} className="px-6" type="button">
                    {isProcessing ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Analyzing Dataset...
                      </>
                    ) : (
                      <>
                        <Upload className="w-4 h-4 mr-2" />
                        Start Analysis
                      </>
                    )}
                  </Button>
                  <Button variant="outline" onClick={handleReset} disabled={isProcessing} type="button">
                    Choose Different File
                  </Button>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <Upload className={`w-12 h-12 mx-auto ${dragActive ? "text-blue-500" : "text-gray-400"}`} />
                <div>
                  <p className="text-lg font-medium text-gray-900">
                    {dragActive ? "Drop your file here" : "Drop your dataset here"}
                  </p>
                  <p className="text-gray-500">or click to browse files</p>
                </div>
                <div>
                  <Button variant="outline" onClick={handleBrowseClick} type="button">
                    <FileText className="w-4 h-4 mr-2" />
                    Choose File
                  </Button>
                </div>
                <p className="text-xs text-gray-400">Supports CSV, Excel (.xlsx, .xls) files up to 100MB</p>
              </div>
            )}
          </div>

          {error && (
            <div className="mt-4 bg-red-50 border border-red-200 rounded-lg p-3">
              <div className="flex items-center">
                <AlertCircle className="w-4 h-4 text-red-600 mr-2" />
                <span className="text-sm font-medium text-red-800">{error}</span>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <div className="max-w-2xl mx-auto">
        <h3 className="font-semibold text-gray-900 mb-3">Supported Analysis Types:</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {[
            "Exploratory Data Analysis",
            "Classification Models",
            "Regression Analysis",
            "Clustering Analysis",
            "Time Series Forecasting",
            "Feature Engineering",
          ].map((type) => (
            <div key={type} className="bg-gray-50 rounded-lg p-3 text-center">
              <p className="text-sm font-medium text-gray-700">{type}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
