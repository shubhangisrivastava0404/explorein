"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { TrendingUp, TrendingDown, Minus } from "lucide-react"

interface EnhancedChartsProps {
  reportData: any
}

export function EnhancedCharts({ reportData }: EnhancedChartsProps) {
  // Enhanced data for more sophisticated visualizations
  const correlationMatrix = [
    { feature1: "Income", feature2: "Performance", correlation: 0.72, strength: "Strong" },
    { feature1: "Experience", feature2: "Performance", correlation: 0.68, strength: "Strong" },
    { feature1: "Education", feature2: "Performance", correlation: 0.45, strength: "Moderate" },
    { feature1: "Income", feature2: "Experience", correlation: 0.58, strength: "Moderate" },
    { feature1: "Location", feature2: "Performance", correlation: 0.23, strength: "Weak" },
    { feature1: "Age", feature2: "Performance", correlation: 0.12, strength: "Weak" },
  ]

  const timeSeriesData = [
    { month: "Jan", accuracy: 82.1, trend: "up" },
    { month: "Feb", accuracy: 83.5, trend: "up" },
    { month: "Mar", accuracy: 85.2, trend: "up" },
    { month: "Apr", accuracy: 84.8, trend: "down" },
    { month: "May", accuracy: 86.3, trend: "up" },
    { month: "Jun", accuracy: 87.3, trend: "up" },
  ]

  const departmentPerformance = [
    { department: "Engineering", performance: 92.5, employees: 45, growth: 8.2 },
    { department: "Sales", performance: 78.3, employees: 32, growth: -2.1 },
    { department: "Marketing", performance: 85.7, employees: 28, growth: 5.4 },
    { department: "HR", performance: 81.2, employees: 15, growth: 1.8 },
    { department: "Finance", performance: 88.9, employees: 22, growth: 3.7 },
  ]

  const riskAnalysis = [
    { factor: "Data Drift", risk: "Low", score: 15, color: "bg-green-500" },
    { factor: "Model Decay", risk: "Medium", score: 35, color: "bg-yellow-500" },
    { factor: "Feature Stability", risk: "Low", score: 20, color: "bg-green-500" },
    { factor: "Prediction Variance", risk: "Medium", score: 40, color: "bg-yellow-500" },
  ]

  const getCorrelationColor = (correlation: number) => {
    if (correlation >= 0.6) return "bg-green-500"
    if (correlation >= 0.3) return "bg-yellow-500"
    return "bg-red-500"
  }

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case "up":
        return <TrendingUp className="w-4 h-4 text-green-500" />
      case "down":
        return <TrendingDown className="w-4 h-4 text-red-500" />
      default:
        return <Minus className="w-4 h-4 text-gray-500" />
    }
  }

  return (
    <div className="space-y-6">
      {/* Correlation Heatmap */}
      <Card>
        <CardHeader>
          <CardTitle>Feature Correlation Heatmap</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {correlationMatrix.map((item, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className={`w-4 h-4 rounded ${getCorrelationColor(Math.abs(item.correlation))}`} />
                  <span className="text-sm font-medium">
                    {item.feature1} ↔ {item.feature2}
                  </span>
                </div>
                <div className="flex items-center space-x-2">
                  <Badge
                    variant={
                      item.strength === "Strong" ? "default" : item.strength === "Moderate" ? "secondary" : "outline"
                    }
                  >
                    {item.strength}
                  </Badge>
                  <span className="text-sm font-bold">{item.correlation.toFixed(2)}</span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Performance Timeline */}
      <Card>
        <CardHeader>
          <CardTitle>Model Performance Timeline</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative">
            <div className="flex justify-between items-end h-40 mb-4">
              {timeSeriesData.map((item, index) => (
                <div key={item.month} className="flex flex-col items-center space-y-2">
                  <div className="flex items-center space-x-1">
                    {getTrendIcon(item.trend)}
                    <span className="text-xs font-bold">{item.accuracy}%</span>
                  </div>
                  <div
                    className="w-8 bg-blue-500 rounded-t transition-all duration-500"
                    style={{ height: `${(item.accuracy - 80) * 4}px` }}
                  />
                  <span className="text-xs text-gray-600">{item.month}</span>
                </div>
              ))}
            </div>
            <div className="text-center">
              <Badge className="bg-green-100 text-green-800">📈 Improving trend: +5.2% over 6 months</Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Department Analysis */}
      <Card>
        <CardHeader>
          <CardTitle>Department Performance Analysis</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {departmentPerformance.map((dept, index) => (
              <div key={dept.department} className="p-4 border rounded-lg">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <h4 className="font-semibold">{dept.department}</h4>
                    <p className="text-sm text-gray-600">{dept.employees} employees</p>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold">{dept.performance}%</div>
                    <div className={`text-sm flex items-center ${dept.growth > 0 ? "text-green-600" : "text-red-600"}`}>
                      {dept.growth > 0 ? (
                        <TrendingUp className="w-3 h-3 mr-1" />
                      ) : (
                        <TrendingDown className="w-3 h-3 mr-1" />
                      )}
                      {Math.abs(dept.growth)}%
                    </div>
                  </div>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full transition-all duration-700"
                    style={{ width: `${dept.performance}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Risk Assessment */}
      <Card>
        <CardHeader>
          <CardTitle>Model Risk Assessment</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            {riskAnalysis.map((risk, index) => (
              <div key={risk.factor} className="p-4 border rounded-lg">
                <div className="flex justify-between items-center mb-2">
                  <h4 className="font-medium text-sm">{risk.factor}</h4>
                  <Badge variant={risk.risk === "Low" ? "secondary" : "destructive"}>{risk.risk}</Badge>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-xs">
                    <span>Risk Score</span>
                    <span className="font-bold">{risk.score}/100</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className={`${risk.color} h-2 rounded-full transition-all duration-500`}
                      style={{ width: `${risk.score}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Advanced Metrics */}
      <Card>
        <CardHeader>
          <CardTitle>Advanced Performance Metrics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center p-4 bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">0.87</div>
              <div className="text-sm text-blue-600">AUC-ROC Score</div>
              <div className="text-xs text-gray-600 mt-1">Excellent discrimination</div>
            </div>
            <div className="text-center p-4 bg-gradient-to-br from-green-50 to-green-100 rounded-lg">
              <div className="text-2xl font-bold text-green-600">0.92</div>
              <div className="text-sm text-green-600">Precision-Recall AUC</div>
              <div className="text-xs text-gray-600 mt-1">High precision maintained</div>
            </div>
            <div className="text-center p-4 bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">0.15</div>
              <div className="text-sm text-purple-600">Log Loss</div>
              <div className="text-xs text-gray-600 mt-1">Low prediction uncertainty</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
