"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Brain, Loader2, CheckCircle } from "lucide-react"

interface ProgressTrackerProps {
  progress: number
  isProcessing: boolean
}

export function ProgressTracker({ progress, isProcessing }: ProgressTrackerProps) {
  const steps = [
    { name: "Data Cleaning", description: "Handling missing values and outliers", progress: 0 },
    { name: "Exploratory Analysis", description: "Generating statistical summaries", progress: 17 },
    { name: "Feature Engineering", description: "Creating and selecting features", progress: 33 },
    { name: "Model Training", description: "Training machine learning models", progress: 50 },
    { name: "Model Evaluation", description: "Comparing model performance", progress: 83 },
    { name: "Generating Insights", description: "Creating AI-powered insights", progress: 100 },
  ]

  const getCurrentStep = () => {
    return steps.findIndex((step) => progress <= step.progress) || steps.length - 1
  }

  const currentStepIndex = getCurrentStep()

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">AI Analysis in Progress</h2>
        <p className="text-gray-600">Our AI is analyzing your dataset and building machine learning models</p>
      </div>

      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Brain className="w-5 h-5 mr-2 text-blue-500" />
            Analysis Progress
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium text-gray-700">Overall Progress</span>
              <span className="text-sm font-medium text-gray-700">{progress}%</span>
            </div>
            <Progress value={progress} className="h-3" />
          </div>

          <div className="space-y-4">
            {steps.map((step, index) => {
              const isCompleted = progress > step.progress
              const isCurrent = index === currentStepIndex && isProcessing
              const isUpcoming = progress < step.progress

              return (
                <div key={step.name} className="flex items-start space-x-3">
                  <div
                    className={`flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center mt-0.5 ${
                      isCompleted ? "bg-green-500" : isCurrent ? "bg-blue-500" : "bg-gray-200"
                    }`}
                  >
                    {isCompleted ? (
                      <CheckCircle className="w-4 h-4 text-white" />
                    ) : isCurrent ? (
                      <Loader2 className="w-4 h-4 text-white animate-spin" />
                    ) : (
                      <div className="w-2 h-2 bg-gray-400 rounded-full" />
                    )}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2">
                      <h4
                        className={`font-medium ${
                          isCompleted ? "text-green-700" : isCurrent ? "text-blue-700" : "text-gray-500"
                        }`}
                      >
                        {step.name}
                      </h4>
                      {isCurrent && (
                        <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                          In Progress
                        </Badge>
                      )}
                      {isCompleted && (
                        <Badge variant="secondary" className="bg-green-100 text-green-800">
                          Completed
                        </Badge>
                      )}
                    </div>
                    <p className={`text-sm ${isCompleted || isCurrent ? "text-gray-600" : "text-gray-400"}`}>
                      {step.description}
                    </p>
                  </div>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>

      <div className="text-center">
        <div className="inline-flex items-center space-x-2 bg-blue-50 text-blue-700 px-4 py-2 rounded-full">
          <Loader2 className="w-4 h-4 animate-spin" />
          <span className="text-sm font-medium">{steps[currentStepIndex]?.name || "Processing..."}</span>
        </div>
      </div>
    </div>
  )
}
