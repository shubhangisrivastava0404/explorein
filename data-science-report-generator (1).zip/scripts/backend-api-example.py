"""
Example Python backend API for the Data Science Report Generator
This would be implemented using FastAPI or Flask
"""

from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report, mean_squared_error, r2_score
from sklearn.preprocessing import LabelEncoder, StandardScaler
import matplotlib.pyplot as plt
import seaborn as sns
import io
import base64
import json
from typing import Dict, List, Any
import openai

app = FastAPI(title="Data Science Report Generator API")

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],  # Next.js dev server
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class DataAnalyzer:
    def __init__(self):
        self.df = None
        self.target_column = None
        self.feature_columns = []
        self.models = {}
        self.results = {}
        
    def load_data(self, file_content: bytes, filename: str) -> Dict[str, Any]:
        """Load and analyze uploaded dataset"""
        try:
            if filename.endswith('.csv'):
                self.df = pd.read_csv(io.BytesIO(file_content))
            elif filename.endswith(('.xlsx', '.xls')):
                self.df = pd.read_excel(io.BytesIO(file_content))
            else:
                raise ValueError("Unsupported file format")
            
            # Analyze dataset
            dataset_info = {
                'filename': filename,
                'rows': len(self.df),
                'columns': len(self.df.columns),
                'columnNames': list(self.df.columns),
                'columnTypes': self._detect_column_types(),
                'missingValues': self.df.isnull().sum().to_dict()
            }
            
            return dataset_info
            
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Error loading data: {str(e)}")
    
    def _detect_column_types(self) -> Dict[str, str]:
        """Detect column types (numeric vs categorical)"""
        column_types = {}
        for col in self.df.columns:
            if self.df[col].dtype in ['int64', 'float64']:
                column_types[col] = 'numeric'
            else:
                column_types[col] = 'categorical'
        return column_types
    
    def clean_data(self):
        """Clean the dataset"""
        # Handle missing values
        numeric_columns = self.df.select_dtypes(include=[np.number]).columns
        categorical_columns = self.df.select_dtypes(exclude=[np.number]).columns
        
        # Fill numeric columns with median
        self.df[numeric_columns] = self.df[numeric_columns].fillna(
            self.df[numeric_columns].median()
        )
        
        # Fill categorical columns with mode
        for col in categorical_columns:
            self.df[col] = self.df[col].fillna(self.df[col].mode()[0] if not self.df[col].mode().empty else 'Unknown')
    
    def perform_eda(self) -> Dict[str, Any]:
        """Perform Exploratory Data Analysis"""
        eda_results = {
            'summary_stats': self.df.describe().to_dict(),
            'correlation_matrix': self.df.corr().to_dict() if len(self.df.select_dtypes(include=[np.number]).columns) > 1 else {},
            'value_counts': {}
        }
        
        # Get value counts for categorical columns
        categorical_columns = self.df.select_dtypes(exclude=[np.number]).columns
        for col in categorical_columns[:5]:  # Limit to first 5 categorical columns
            eda_results['value_counts'][col] = self.df[col].value_counts().head(10).to_dict()
        
        return eda_results
    
    def train_models(self, target_column: str, analysis_type: str, model_types: List[str], test_size: float = 0.2):
        """Train machine learning models"""
        self.target_column = target_column
        self.feature_columns = [col for col in self.df.columns if col != target_column]
        
        # Prepare features
        X = self.df[self.feature_columns].copy()
        y = self.df[target_column].copy()
        
        # Encode categorical variables
        label_encoders = {}
        for col in X.select_dtypes(exclude=[np.number]).columns:
            le = LabelEncoder()
            X[col] = le.fit_transform(X[col].astype(str))
            label_encoders[col] = le
        
        # Encode target if classification
        if analysis_type == 'classification' and y.dtype == 'object':
            target_encoder = LabelEncoder()
            y = target_encoder.fit_transform(y)
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=test_size, random_state=42
        )
        
        # Scale features
        scaler = StandardScaler()
        X_train_scaled = scaler.fit_transform(X_train)
        X_test_scaled = scaler.transform(X_test)
        
        # Train models
        model_results = {}
        
        for model_name in model_types:
            try:
                if analysis_type == 'classification':
                    if model_name == 'Random Forest':
                        model = RandomForestClassifier(n_estimators=100, random_state=42)
                        model.fit(X_train, y_train)
                        y_pred = model.predict(X_test)
                        
                        accuracy = accuracy_score(y_test, y_pred)
                        report = classification_report(y_test, y_pred, output_dict=True)
                        
                        model_results[model_name] = {
                            'accuracy': accuracy,
                            'precision': report['weighted avg']['precision'],
                            'recall': report['weighted avg']['recall'],
                            'f1_score': report['weighted avg']['f1-score'],
                            'feature_importance': dict(zip(self.feature_columns, model.feature_importances_))
                        }
                        
                    elif model_name == 'Logistic Regression':
                        model = LogisticRegression(random_state=42, max_iter=1000)
                        model.fit(X_train_scaled, y_train)
                        y_pred = model.predict(X_test_scaled)
                        
                        accuracy = accuracy_score(y_test, y_pred)
                        report = classification_report(y_test, y_pred, output_dict=True)
                        
                        model_results[model_name] = {
                            'accuracy': accuracy,
                            'precision': report['weighted avg']['precision'],
                            'recall': report['weighted avg']['recall'],
                            'f1_score': report['weighted avg']['f1-score']
                        }
                
                elif analysis_type == 'regression':
                    if model_name == 'Random Forest':
                        model = RandomForestRegressor(n_estimators=100, random_state=42)
                        model.fit(X_train, y_train)
                        y_pred = model.predict(X_test)
                        
                        r2 = r2_score(y_test, y_pred)
                        mse = mean_squared_error(y_test, y_pred)
                        
                        model_results[model_name] = {
                            'r2_score': r2,
                            'mse': mse,
                            'rmse': np.sqrt(mse),
                            'feature_importance': dict(zip(self.feature_columns, model.feature_importances_))
                        }
                        
                    elif model_name == 'Linear Regression':
                        model = LinearRegression()
                        model.fit(X_train_scaled, y_train)
                        y_pred = model.predict(X_test_scaled)
                        
                        r2 = r2_score(y_test, y_pred)
                        mse = mean_squared_error(y_test, y_pred)
                        
                        model_results[model_name] = {
                            'r2_score': r2,
                            'mse': mse,
                            'rmse': np.sqrt(mse)
                        }
                        
            except Exception as e:
                model_results[model_name] = {'error': str(e)}
        
        self.results = model_results
        return model_results
    
    def generate_insights(self, analysis_results: Dict[str, Any]) -> List[str]:
        """Generate AI-powered insights using OpenAI"""
        try:
            # This would use the OpenAI API to generate insights
            # For demo purposes, we'll return mock insights
            insights = [
                f"The best performing model achieved {analysis_results.get('best_accuracy', 0.85)*100:.1f}% accuracy.",
                "Feature importance analysis reveals the top predictive factors.",
                "Data quality is good with minimal missing values requiring imputation.",
                "Model performance suggests the dataset has strong predictive signals."
            ]
            return insights
        except Exception as e:
            return [f"Error generating insights: {str(e)}"]

# Global analyzer instance
analyzer = DataAnalyzer()

@app.post("/api/upload")
async def upload_dataset(file: UploadFile = File(...)):
    """Upload and analyze dataset"""
    if not file.filename.endswith(('.csv', '.xlsx', '.xls')):
        raise HTTPException(status_code=400, detail="Only CSV and Excel files are supported")
    
    content = await file.read()
    dataset_info = analyzer.load_data(content, file.filename)
    
    return {"success": True, "dataset_info": dataset_info}

@app.post("/api/analyze")
async def analyze_data(config: Dict[str, Any]):
    """Perform data analysis based on configuration"""
    try:
        # Clean data
        analyzer.clean_data()
        
        # Perform EDA
        eda_results = analyzer.perform_eda()
        
        analysis_type = config.get('analysisType', 'eda')
        
        if analysis_type != 'eda':
            # Train models
            target_column = config.get('targetVariable')
            model_types = config.get('modelTypes', [])
            test_size = config.get('testSize', 0.2)
            
            model_results = analyzer.train_models(
                target_column, analysis_type, model_types, test_size
            )
            
            # Find best model
            best_model = None
            best_score = 0
            
            for model_name, results in model_results.items():
                if 'error' not in results:
                    if analysis_type == 'classification':
                        score = results.get('accuracy', 0)
                    else:
                        score = results.get('r2_score', 0)
                    
                 
                        score = results.get('r2_score', 0)
                    
                    if score > best_score:
                        best_score = score
                        best_model = model_name
            
            # Generate insights
            insights = analyzer.generate_insights({
                'best_model': best_model,
                'best_accuracy': best_score,
                'model_results': model_results
            })
            
            return {
                "success": True,
                "analysis_type": analysis_type,
                "eda_results": eda_results,
                "model_results": model_results,
                "best_model": best_model,
                "insights": insights
            }
        else:
            # EDA only
            insights = [
                f"Dataset contains {len(analyzer.df)} records with {len(analyzer.df.columns)} features.",
                "Data quality assessment completed with missing value analysis.",
                "Statistical summaries and distributions have been calculated.",
                "Correlation analysis reveals relationships between numeric variables."
            ]
            
            return {
                "success": True,
                "analysis_type": analysis_type,
                "eda_results": eda_results,
                "insights": insights
            }
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Analysis failed: {str(e)}")

@app.get("/api/export-report")
async def export_report():
    """Export analysis report as PDF"""
    # This would generate a PDF report using libraries like ReportLab
    # For demo purposes, we'll return a success message
    return {"success": True, "message": "Report exported successfully"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
