"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Upload, FileText, BarChart3, Brain } from "lucide-react"
import { toast } from "@/hooks/use-toast"
import { DataUpload } from "@/components/data-upload"
import { AnalysisConfigComponent } from "@/components/analysis-config"
import { ReportViewer } from "@/components/report-viewer"
import { ProgressTracker } from "@/components/progress-tracker"

type AnalysisStep = "upload" | "config" | "processing" | "results"

interface DatasetInfo {
  filename: string
  rows: number
  columns: number
  columnNames: string[]
  columnTypes: Record<string, string>
  missingValues: Record<string, number>
}

interface AnalysisConfig {
  analysisType: "eda" | "classification" | "regression" | "clustering" | "timeseries"
  targetVariable?: string
  features?: string[]
  testSize: number
  randomState: number
  modelTypes: string[]
}

export default function DataScienceGenerator() {
  const [currentStep, setCurrentStep] = useState<AnalysisStep>("upload")
  const [uploadedFile, setUploadedFile] = useState<File | null>(null)
  const [datasetInfo, setDatasetInfo] = useState<DatasetInfo | null>(null)
  const [analysisConfig, setAnalysisConfig] = useState<AnalysisConfig>({
    analysisType: "eda",
    testSize: 0.2,
    randomState: 42,
    modelTypes: ["Random Forest", "Linear Regression"],
  })
  const [isProcessing, setIsProcessing] = useState(false)
  const [processingProgress, setProcessingProgress] = useState(0)
  const [reportData, setReportData] = useState<any>(null)

  const handleFileUpload = async (file: File) => {
    console.log("=== FILE UPLOAD STARTED ===")
    console.log("File:", file.name, file.size, file.type)

    setUploadedFile(file)
    setIsProcessing(true)

    try {
      console.log("Starting file analysis...")

      // Simulate API call to analyze dataset
      await new Promise((resolve) => setTimeout(resolve, 2000))

      console.log("File analysis complete, creating mock data...")

      // Mock dataset info based on file
      const mockDatasetInfo: DatasetInfo = {
        filename: file.name,
        rows: Math.floor(Math.random() * 5000) + 500,
        columns: 8,
        columnNames: ["age", "income", "education", "experience", "location", "department", "salary", "performance"],
        columnTypes: {
          age: "numeric",
          income: "numeric",
          education: "categorical",
          experience: "numeric",
          location: "categorical",
          department: "categorical",
          salary: "numeric",
          performance: "numeric",
        },
        missingValues: {
          age: Math.floor(Math.random() * 10),
          income: Math.floor(Math.random() * 15),
          education: 0,
          experience: Math.floor(Math.random() * 5),
          location: Math.floor(Math.random() * 3),
          department: 0,
          salary: Math.floor(Math.random() * 10),
          performance: Math.floor(Math.random() * 20),
        },
      }

      console.log("Setting dataset info:", mockDatasetInfo)
      setDatasetInfo(mockDatasetInfo)

      console.log("Changing step to config...")
      setCurrentStep("config")

      console.log("=== FILE UPLOAD COMPLETED ===")

      toast({
        title: "Dataset uploaded successfully",
        description: `Analyzed ${mockDatasetInfo.rows} rows and ${mockDatasetInfo.columns} columns`,
      })
    } catch (error) {
      console.error("=== FILE UPLOAD ERROR ===", error)
      toast({
        title: "Upload failed",
        description: "Please try again with a valid CSV or Excel file",
        variant: "destructive",
      })
    } finally {
      console.log("Setting isProcessing to false")
      setIsProcessing(false)
    }
  }

  const handleStartAnalysis = async () => {
    console.log("=== ANALYSIS STARTED ===")
    console.log("Current config:", analysisConfig)
    console.log("Dataset info:", datasetInfo)

    setCurrentStep("processing")
    setIsProcessing(true)
    setProcessingProgress(0)

    // Simulate analysis steps
    const steps = [
      { name: "Data Cleaning", duration: 1000 },
      { name: "Exploratory Data Analysis", duration: 1500 },
      { name: "Feature Engineering", duration: 1200 },
      { name: "Model Training", duration: 2000 },
      { name: "Model Evaluation", duration: 800 },
      { name: "Generating Insights", duration: 1500 },
    ]

    let progress = 0
    for (const step of steps) {
      await new Promise((resolve) => setTimeout(resolve, step.duration))
      progress += 100 / steps.length
      setProcessingProgress(Math.round(progress))
    }

    // Mock report data
    const mockReportData = {
      summary: {
        datasetName: uploadedFile?.name,
        analysisType: analysisConfig.analysisType,
        totalRows: datasetInfo?.rows,
        totalColumns: datasetInfo?.columns,
        missingValuesHandled: 44,
        modelsTrained: analysisConfig.modelTypes.length,
      },
      insights: [
        "The Random Forest model achieved the highest accuracy of 87.3% for predicting performance ratings.",
        "Income and experience show the strongest correlation with performance (r=0.72 and r=0.68 respectively).",
        "The Engineering department shows 15% higher average performance compared to other departments.",
        "Age appears to have minimal impact on performance prediction (feature importance: 0.03).",
      ],
      modelResults: {
        bestModel: "Random Forest",
        accuracy: 0.873,
        precision: 0.851,
        recall: 0.892,
        f1Score: 0.871,
      },
      visualizations: [
        { type: "correlation_heatmap", title: "Feature Correlation Matrix" },
        { type: "feature_importance", title: "Feature Importance Ranking" },
        { type: "distribution_plots", title: "Target Variable Distribution" },
        { type: "confusion_matrix", title: "Model Performance Matrix" },
      ],
    }

    setReportData(mockReportData)
    setCurrentStep("results")
    setIsProcessing(false)

    toast({
      title: "Analysis completed!",
      description: "Your comprehensive data science report is ready",
    })
  }

  const handleExportReport = () => {
    toast({
      title: "Report exported",
      description: "PDF report has been downloaded to your device",
    })
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">AI-Powered Data Science Report Generator</h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Upload your dataset and let AI automatically perform comprehensive data analysis, build machine learning
            models, and generate professional reports with insights.
          </p>
        </div>

        {/* Progress Steps */}
        <div className="mb-8">
          <div className="flex items-center justify-center space-x-4">
            {[
              { key: "upload", label: "Upload Data", icon: Upload },
              { key: "config", label: "Configure Analysis", icon: FileText },
              { key: "processing", label: "AI Processing", icon: Brain },
              { key: "results", label: "View Report", icon: BarChart3 },
            ].map((step, index) => {
              const Icon = step.icon
              const isActive = currentStep === step.key
              const isCompleted = ["upload", "config", "processing", "results"].indexOf(currentStep) > index

              return (
                <div key={step.key} className="flex items-center">
                  <div
                    className={`flex items-center justify-center w-10 h-10 rounded-full border-2 ${
                      isActive
                        ? "border-blue-500 bg-blue-500 text-white"
                        : isCompleted
                          ? "border-green-500 bg-green-500 text-white"
                          : "border-gray-300 bg-white text-gray-400"
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                  </div>
                  <span
                    className={`ml-2 text-sm font-medium ${
                      isActive || isCompleted ? "text-gray-900" : "text-gray-400"
                    }`}
                  >
                    {step.label}
                  </span>
                  {index < 3 && <div className={`w-8 h-0.5 mx-4 ${isCompleted ? "bg-green-500" : "bg-gray-300"}`} />}
                </div>
              )
            })}
          </div>
        </div>

        {/* Debug Info - Remove in production */}
        <div className="mb-4 p-4 bg-gray-100 rounded-lg text-sm">
          <p>
            <strong>Current Step:</strong> {currentStep}
          </p>
          <p>
            <strong>Is Processing:</strong> {isProcessing.toString()}
          </p>
          <p>
            <strong>Uploaded File:</strong> {uploadedFile?.name || "None"}
          </p>
          <p>
            <strong>Dataset Info:</strong> {datasetInfo ? "Available" : "None"}
          </p>
          <p>
            <strong>Analysis Config:</strong> {JSON.stringify(analysisConfig, null, 2)}
          </p>
        </div>

        {/* Main Content */}
        <div className="bg-white rounded-lg shadow-lg p-6">
          {currentStep === "upload" && <DataUpload onFileUpload={handleFileUpload} isProcessing={isProcessing} />}

          {currentStep === "config" && datasetInfo && (
            <AnalysisConfigComponent
              datasetInfo={datasetInfo}
              config={analysisConfig}
              onConfigChange={setAnalysisConfig}
              onStartAnalysis={handleStartAnalysis}
            />
          )}

          {currentStep === "processing" && (
            <ProgressTracker progress={processingProgress} isProcessing={isProcessing} />
          )}

          {currentStep === "results" && reportData && (
            <ReportViewer reportData={reportData} onExportReport={handleExportReport} />
          )}
        </div>

        {/* Features Section */}
        <div className="mt-12 grid md:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Brain className="w-5 h-5 mr-2 text-blue-500" />
                Automated Analysis
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                AI automatically cleans data, performs EDA, and builds multiple ML models to find the best performing
                solution for your dataset.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <BarChart3 className="w-5 h-5 mr-2 text-green-500" />
                Rich Visualizations
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Generate comprehensive charts, correlation matrices, feature importance plots, and model performance
                visualizations automatically.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <FileText className="w-5 h-5 mr-2 text-purple-500" />
                Professional Reports
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Export detailed PDF reports with AI-generated insights, recommendations, and actionable business
                intelligence from your data.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
